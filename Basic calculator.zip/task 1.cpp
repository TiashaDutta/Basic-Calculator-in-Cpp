#include <iostream>

void showMenu() {
    std::cout << "Basic Calculator" << std::endl;
    std::cout << "----------------" << std::endl;
    std::cout << "Choose an operation:" << std::endl;
    std::cout << "1. Addition (+)" << std::endl;
    std::cout << "2. Subtraction (-)" << std::endl;
    std::cout << "3. Multiplication (*)" << std::endl;
    std::cout << "4. Division (/)" << std::endl;
    std::cout << "5. Exit" << std::endl;
    std::cout << "----------------" << std::endl;
}

int main() {
    double num1, num2;
    char operation;
    bool keepRunning = true;

    while (keepRunning) {
        showMenu();
        std::cout << "Enter the number corresponding to the operation: ";
        int choice;
        std::cin >> choice;

        if (choice == 5) {
            std::cout << "Exiting..." << std::endl;
            break;
        }

        std::cout << "Enter first number: ";
        std::cin >> num1;
        std::cout << "Enter second number: ";
        std::cin >> num2;

        switch (choice) {
            case 1:
                std::cout << "Result: " << num1 + num2 << std::endl;
                break;
            case 2:
                std::cout << "Result: " << num1 - num2 << std::endl;
                break;
            case 3:
                std::cout << "Result: " << num1 * num2 << std::endl;
                break;
            case 4:
                if (num2 != 0) {
                    std::cout << "Result: " << num1 / num2 << std::endl;
                } else {
                    std::cout << "Error: Division by zero!" << std::endl;
                }
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
                break;
        }

        std::cout << "Do you want to perform another operation? (y/n): ";
        char continueChoice;
        std::cin >> continueChoice;
        if (continueChoice == 'n' || continueChoice == 'N') {
            keepRunning = false;
            std::cout << "Exiting..." << std::endl;
        }
    }

    return 0;
}
